package Constants;

public class ConstantsData {
	
	public final static String PropertyFilepath="src/main/java/Global.properties";
	public final static String ExcelPath="src/test/java/Utilities/ExcelFile/BDD Test.xlsx";
	

}
