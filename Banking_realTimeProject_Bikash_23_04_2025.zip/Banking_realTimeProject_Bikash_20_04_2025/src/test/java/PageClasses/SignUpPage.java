package PageClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Utilities.BaseClass;

public class SignUpPage extends BaseClass {
	
	WebDriver driver;
	
	public SignUpPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[normalize-space()='Sign Up']")
	WebElement signuplink;
	
	@FindBy(xpath="//input[@name='First Name']")
	WebElement FirstName;
	
	@FindBy(xpath="//input[@name='Last Name']")
	WebElement LastName;
	
	@FindBy(xpath="//input[@name='Phone']")
	WebElement PhoneNo;
	
	@FindBy(xpath="//input[@id='input_1742711839224']")
	WebElement DOB;
	
	@FindBy(xpath="//td[@class='t_datepicker__day-cell t_datepicker__current-month t_datepicker__past'][normalize-space()='1']")
	WebElement SelectDate;

	@FindBy(xpath="//select[@id='input_1742711863977']")
	WebElement Gender;
	
	@FindBy(xpath="//input[@id='input_1742711965354']")
	WebElement City;
	
	@FindBy(xpath="//input[@id='input_1742711986078']")
	WebElement UserName;
	
	@FindBy(xpath="//input[@id='input_1742712432708']")
	WebElement Password;
	
	@FindBy(xpath="//button[@class='t-submit']")
	WebElement SignupBtn;
	
	@FindBy(xpath="//div[@class='js-successbox t-form__successbox t-text t-text_md']")
	WebElement VerifySignUp;
	
	public void clicksSignUpLink()
	{
		signuplink.click();
	}
	
	public void enterFirstName(String firstname)
	{
		FirstName.sendKeys(firstname);
	}
	
	public void enterLastName(String lastname)
	{
		LastName.sendKeys(lastname);
	}
	
	public void enterPhone(String phonenumber)
	{
		PhoneNo.sendKeys(phonenumber);
	}
	
	public void SelectDOB()
	{
		DOB.click();
		SelectDate.click();
	}
	
	public void selectGender(int x)
	{
		Select gen=new Select(Gender);
		gen.selectByIndex(x);
	}
	
	public void enterCity(String city)
	{
		City.sendKeys(city);
	}
	
	public void enterUsername(String username)
	{
		UserName.sendKeys(username);
	}
	
	public void enterPassword(String password)
	{
		Password.sendKeys(password);
	}
	
	public void clickSignUpBtn()
	{
		SignupBtn.click();
	}
	
	public void VerifySignUp()
	{
		VerifySignUp.isDisplayed();
		//String text=VerifySignUp.getText();
		//return text;
	}
	
}
