package PageClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
WebDriver driver;
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[contains(text(),'Log In')]")
	WebElement loginlink;
	
	@FindBy(xpath="//input[@name='Input']")
	WebElement userNameTxt;
	
	@FindBy(xpath="//input[@id='input_1742715919526']")
	WebElement passwordTxt;
	
	@FindBy(xpath="//button[@class='t-submit']")
	WebElement loginBtn;
	
	@FindBy(xpath="//div[contains(text(),'Thank you! Your data has been submitted.')]")
	WebElement verifyText;
	
	
	
	public void clickLoginLink()
	{
		loginlink.click();
	}
	
	public void enterUserName(String un)
	{
		userNameTxt.sendKeys(un);
	}
	
	public void enterPassword(String pwd)
	{
		passwordTxt.sendKeys(pwd);
	}
	
	public void clickLogin()
	{
		loginBtn.click();
	}
	
	public void verifyTextMsg()
	{
		//verifyText.isDisplayed();
	}
	

}
