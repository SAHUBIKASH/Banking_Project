package PageClasses;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;  // Correct import for Duration

import Utilities.BaseClass;

public class AccountDetailsPage extends BaseClass {
    WebDriver driver;
    WebDriverWait wait;

    public AccountDetailsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));  // Corrected Duration usage
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[contains(text(),'Account Detail')]")
    WebElement AccDetailslink;

    @FindBy(xpath = "//select[@id='collection_comp-m8swuunx']")
    WebElement SelectName;

    @FindBy(xpath = "//option[text()='Rahul']")
    WebElement SelectRahul;

    @FindBy(xpath = "//span[contains(text(),'Login')]")
    WebElement loginBtn;
    
    
    @FindBy(xpath = "//span[text()='Transaction ']")
    WebElement VerifyAccDetails;
    


    @FindBy(xpath = "//*[@id=\"tab-comp-m8szwsxa\"]/span")
    WebElement Deposit;
    
    @FindBy(xpath="//input[@id='input_comp-m8t00o79']")
    WebElement DepositAmount;

    @FindBy(xpath="//*[@id=\"comp-m8t0270q\"]/button")
    WebElement DepositBtn;
    
    @FindBy(xpath="//div[@id='comp-m8szvumq']")
    WebElement verifyDepBalance;
    
    @FindBy(xpath="//span[text()=' Withdrawl']")
    WebElement Withdraw;
    
    @FindBy(xpath="//span[text()=' Withdrawl']")
    WebElement WithdrawLink;
    
    @FindBy(xpath="//input[@id='input_comp-m8t03jwk']")
    WebElement WithdrawAmount;
    
    @FindBy(xpath="//span[text()='Withdraw']")
    WebElement WithdrawBtn;
    
    @FindBy(id="comp-m8szvumq")
    WebElement verifyWithBalance;
    
    
    
    
    public void clicksAccDetLink() {
        AccDetailslink.click();
    }
    
    

    public void selectWixDropdown() throws InterruptedException {
        // Wait until the dropdown is clickable
    	wait.until(ExpectedConditions.elementToBeClickable(SelectName)).click();
    	Thread.sleep(5000);
    	SelectName.sendKeys(Keys.ARROW_DOWN); // if Rahul is first or second option
        SelectName.sendKeys(Keys.ARROW_DOWN);
        SelectName.sendKeys(Keys.ENTER); // Confirm selection
        SelectName.sendKeys(Keys.ENTER); // Confirm selection
        SelectName.sendKeys(Keys.ARROW_DOWN);
        SelectName.sendKeys(Keys.ENTER); // Confirm selection
    }
//    public void selectWixDropdown() {
//        // Open the dropdown
//        wait.until(ExpectedConditions.elementToBeClickable(SelectName)).click();
//       
//
//        // Small wait to ensure dropdown options are rendered
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        // Navigate using arrow keys
//        for (int i = 0; i < 5; i++) {
//            SelectName.sendKeys(Keys.ARROW_DOWN);
//            try {
//                Thread.sleep(500); // let UI update
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//            }
//            
//
//            // Check the selected value
//            String selectedText = SelectName.getAttribute("value");
//            System.out.println("Attempt " + (i + 1) + ": Selected value = " + selectedText);
//            
//            String text = (String) ((JavascriptExecutor) driver).executeScript(
//            	    "return arguments[0].options[arguments[0].selectedIndex].text;", SelectName);
//            	System.out.println("Attempt " + (i + 1) + ": Visible text = " + text);
//
//
//            if (selectedText != null && selectedText.equalsIgnoreCase("Rahul")) {
//                SelectName.sendKeys(Keys.ENTER);
//                System.out.println("'Rahul' is selected successfully.");
//                return;
//            }
//        }
//
//        // If Rahul was not selected
//        throw new RuntimeException("Unable to select 'Rahul' from dropdown.");
//    }
	/*
	 * public void selectWixDropdown() { // WebDriverWait wait = new
	 * WebDriverWait(driver,Duration.ofSeconds(20)); //
	 * wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	 * SelectName.click(); Thread.sleep(3000);
	 * 
	 * Robot sw= new Robot(); sw.keyPress(KeyEvent.VK_DOWN); // Thread.sleep(3000);
	 * // driver.navigate().refresh(); sw.keyPress(KeyEvent.VK_ENTER);
	 * SelectName.click(); sw.keyPress(KeyEvent.VK_DOWN); Thread.sleep(3000);
	 * sw.keyPress(KeyEvent.VK_DOWN); sw.keyPress(KeyEvent.VK_ENTER); //
	 * element.sendKeys(Keys.DOWN); // element.sendKeys(Keys.DOWN); //
	 * element.sendKeys(Keys.ENTER); //
	 * driver.findElement(By.xpath("//span[.='Login']")).click();            }
	 */





    public void Login() {
        loginBtn.click();
    }
    
    public void verifyAccDetails() {
    	//VerifyAccDetails.isDisplayed();
    	Assert.assertTrue(VerifyAccDetails.isDisplayed(), "Account Details Page is not displayed");
    	
    }
    
    public void clickDeposit() throws InterruptedException {
        Deposit.click();
        Thread.sleep(3000);
        DepositAmount.sendKeys("5000");
        Thread.sleep(3000);
        DepositBtn.click();
    }
    public void VerifyDepositBalance() throws InterruptedException {
    	
    	Thread.sleep(2000);
    	String expectedAmount = "5000".replaceAll("[^0-9]", ""); // Removes ₹, spaces, etc.

    	WebElement balanceElement = verifyDepBalance;
    	String actualAmount = balanceElement.getText().replaceAll("[^0-9]", ""); // Removes ₹, spaces, etc.

    	Assert.assertEquals(expectedAmount, actualAmount);
    }
    
    public void clickWithdrawLink() throws InterruptedException {
        WithdrawLink.click();
        Thread.sleep(3000);
        WithdrawAmount.sendKeys("5000");
        Thread.sleep(3000);
        WithdrawBtn.click();
    }
 public void VerifyBalance() throws InterruptedException {
    	
    	Thread.sleep(2000);
    	String expectedAmount = "0".replaceAll("[^0-9]", ""); // Removes ₹, spaces, etc.

    	WebElement balanceElement = verifyWithBalance;
    	String actualAmount = balanceElement.getText().replaceAll("[^0-9]", ""); // Removes ₹, spaces, etc.

    	Assert.assertEquals(expectedAmount, actualAmount);
    }
    
    
}
