package PageClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForgotPassword {

WebDriver driver;
	
	public ForgotPassword(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath ="//a[normalize-space()='Forget Password']")
	WebElement FPlink;
	
	@FindBy(xpath="//input[@name='Input']")
	WebElement mailId;
	
	@FindBy(xpath="//input[@name='Input_2']")
	WebElement mobNo;
	
	@FindBy(xpath="//button[@class='t-submit']")
	WebElement reset;
	
	@FindBy(xpath="//div[text()='Thank you! Your data has been submitted.']")
	WebElement verifyText;
	
	
	
	public void clickForgetPasswordLink()
	{
		FPlink.click();
	}
	
	public void enterEmail(String emailIDD)
	{
		mailId.sendKeys(emailIDD);
	}
	
	public void EnterMobileNumber(String mobileNo)
	{
		mobNo.sendKeys(mobileNo);
	}
	
	public void clickResetPassword()
	{
		reset.click();
	}
	public void verifyText()
	{
		verifyText.isDisplayed();
		
	
	}
	
	
	
	
}
