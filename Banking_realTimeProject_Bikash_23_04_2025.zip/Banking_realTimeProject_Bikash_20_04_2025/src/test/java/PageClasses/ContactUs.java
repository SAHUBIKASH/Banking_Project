package PageClasses;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactUs {
	
WebDriver driver;
	
	public ContactUs(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[contains(text(),'Contacts Us')]")
	WebElement contactUslink;
	
	@FindBy(xpath="//input[@name='Input']")
	WebElement yourName;
	
	@FindBy(xpath="//input[@name='Input_2']")
	WebElement yourEmail;
	
	@FindBy(xpath="//input[@name='Input_3']")
	WebElement phoneNo;
	
	@FindBy(xpath="//input[@name='Input_4']")
	WebElement address;
	
	@FindBy(xpath="//input[@name='Input_5']")
	WebElement country;
	
	@FindBy(xpath="//input[@name='Input_6']")
	WebElement zipCode;
	
	@FindBy(xpath="//button[@class='t-submit']")
	WebElement submit ;
	
	@FindBy(xpath="//div[text()='Thank you! Your data has been submitted.']")
	WebElement verifyText ;
	
	
	public void clickContactUsLink()
	{
		contactUslink.click();
	}
	
//	public void enterYN(String x)
//	{
//		yourName.sendKeys(x);
//	}
//	
//	public void enterYE(String y)
//	{
//		yourEmail.sendKeys(y);
//	}
//	
//	public void enterPN(String a)
//	{
//		phoneNo.sendKeys(a);
//	}
//	
//	public void enterAddress(String b)
//	{
//		address.sendKeys(b);
//	}
//	
//	public void enterCountry(String c)
//	{
//		country.sendKeys(c);
//	}
//	
//	public void enterZC(String d)
//	{
//		zipCode.sendKeys(d);
//	}
	
	 public void fillContactForm(String name, String email, String phone, String addr, String ctry, String zip) {
	        yourName.sendKeys(name);
	        yourEmail.sendKeys(email);
	        phoneNo.sendKeys(phone);
	        address.sendKeys(addr);
	        country.sendKeys(ctry);
	        zipCode.sendKeys(zip);
	    }
	
	public void ClickSubmit()
	{
		submit.click();
	}
	
	public String VerifyText()
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement successMsg = wait.until(ExpectedConditions.visibilityOf(verifyText));
		return verifyText.getText();
	}

}
