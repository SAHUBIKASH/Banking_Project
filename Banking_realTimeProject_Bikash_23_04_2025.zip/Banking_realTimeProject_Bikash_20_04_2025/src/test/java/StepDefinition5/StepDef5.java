package StepDefinition5;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageClasses.AccountDetailsPage;
import PageClasses.ContactUs;
import PageClasses.ForgotPassword;
import PageClasses.LoginPage;
import PageClasses.SignUpPage;
import Utilities.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDef5 extends BaseClass {

	// WebDriver driver;
	WebDriver driver = BaseClass.initializeDriver();
	SignUpPage signup = new SignUpPage(driver);
	AccountDetailsPage accdetail = new AccountDetailsPage(driver);
	LoginPage lgpage = new LoginPage(driver);
	ForgotPassword fp = new ForgotPassword(driver);
	ContactUs cs=new ContactUs(driver);
	
	
//----------------------------DB Connection-----------------------------------
	@Before
	public void setUp() {
		System.out.println("Before method is executed");
		 // Initialize DB connection
	    System.out.println("Setting up DB connection...");
	}




	// -----------------------Sign Up Page---------------------------------------------

	@Given("user open the url for banking application")
	public void user_open_the_url_for_banking_application() {

		System.out.println("Application lunched");

		// initialize logger
		log = org.apache.logging.log4j.LogManager.getLogger("StepDef5");

		// System.out.println(getPageTitle());

		// String x=getPageTitle();
		// Assert.assertEquals(x, "Log In");

		log.info("User Opens the URL for banking application");
	}

	@Given("user clicks on SignUp link")
	public void user_clicks_on_sign_up_button() {

		signup.clicksSignUpLink();

		log.info("User clicks on SignUp link");
	}

	@Given("user enters the firstname as {string}")
	public void user_enters_the_firstname_as(String firstname) {

		signup.enterFirstName(firstname);

		log.info("User enters the firstname");
	}

	@Given("user enters the lastname as {string}")
	public void user_enters_the_lastname_as(String lastname) {

		signup.enterLastName(lastname);
		log.info("User enters the LastName");
	}

	@Given("user enters the phoneNumber as {string}")
	public void user_enters_the_phone_number_as(String phonenumber) {

		addExplicitWait(By.xpath("//input[@name='Phone']"));

		signup.enterPhone(phonenumber);

		scrollDown();
		log.info("User enters the phoneNumber");
	}

	@Given("user selects DOB")
	public void user_selects_dob() {

		signup.SelectDOB();

		log.info("User selects DOB");

	}

	@Given("user selects gender")
	public void user_selects_gender() throws InterruptedException {
		hardCodedWait();
		signup.selectGender(1);

		log.info("User selects Gender");

	}

	@Given("user enters the cityname as {string}")
	public void user_enters_the_cityname_as(String city) {
		signup.enterCity(city);

		log.info("User enters the cityname");

	}

	@Given("user enters the userid as {string}")
	public void user_enters_the_userid_as(String uid) {

		signup.enterUsername(uid);

		log.info("User enters the UserID");

	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String password) {

		signup.enterPassword(password);

		log.info("User enters the Password");
	}

	@When("user clicks on signup button")
	public void user_clicks_on_signup_button() {
		signup.clickSignUpBtn();

		log.info("User clicks on signup button");
	}

	@Then("user will get a message from the site")
	public void user_will_get_a_message_from_the_site() throws InterruptedException {
		hardCodedWait();
		signup.VerifySignUp();

		log.info("user will get a message from the site");

		// String Exptext=signup.VerifySignUp();
		// Assert.assertEquals(actualtext, Exptext);

		// log.info("User will get a message from the site");

	}
	
	
	
	// ----------------------Account Details Page-------------------------------------------

	@Given("the user clicks on the Account Details link")
	public void the_user_clicks_on_the_account_details_link() {
		accdetail.clicksAccDetLink();

		log.info("user has clicked the Account Details link");

	}

	@Then("a new window opens with the banking site")
	public void a_new_window_opens_with_the_banking_site() {

		switchToNewWindow();

		log.info("new window have opened with the banking site");

	}

	@Then("the user selects a name from the Your Name dropdown")
	public void the_user_selects_a_name_from_the_your_name_dropdown() throws Exception {

		accdetail.selectWixDropdown();
		hardCodedWait();

		log.info("user has selected a name from the Your Name dropdown");
	}

	@When("the user clicks the Login button")
	public void the_user_clicks_the_login_button() {
		accdetail.Login();

		log.info("user has clicked the login button");

	}

	@Then("the banking home page should be displayed and verified for correctness")
	public void the_banking_home_page_should_be_displayed_and_verified_for_correctness() {

		// accdetail.verifyAccDetails();
		String actualTitle = "HOME | banking";

		String ExpTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, ExpTitle);

		log.info("the banking home page is displayed and verified for correct");

	}

	@When("the user deposits an amount")
	public void the_user_deposits_an_amount() throws InterruptedException {

		hardCodedWait();
		accdetail.clickDeposit();

		log.info("the user has deposited the amount");
	}

	@Then("the deposited amount should reflect in the account balance")
	public void the_deposited_amount_should_reflect_in_the_account_balance() throws InterruptedException {

		accdetail.VerifyDepositBalance();

		log.info("deposited amount is reflecting in the balance");

	}

	@When("the user withdraws the entire deposited amount")
	public void the_user_withdraws_the_entire_deposited_amount() throws InterruptedException {

		accdetail.clickWithdrawLink();

		log.info("user has withdrawn the entire deposited amount");

	}

	@Then("the account balance should be zero")
	public void the_account_balance_should_be_zero() throws InterruptedException {

		accdetail.VerifyBalance();

		log.info("After withdrawal of total amount, Account balance is zero");
	}

	
	
	
	// ---------------------------------Login page-------------------------------------------
	
	
	@Given("user clicks on Login link button")
	public void user_clicks_on_login_link_button() {

		lgpage.clickLoginLink();

	}

	@When("user enters the username {string}")
	public void user_enters_the_username(String username) {

		lgpage.enterUserName(username);

	}

	@When("user enters the password {string}")
	public void user_enters_the_password(String password) {

		lgpage.enterPassword(password);
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {

		String actual = "Log In";
		String exp = driver.getTitle();
		Assert.assertEquals(actual, exp);

	}

	@Then("the text after login should be validated")
	public void the_text_after_login_should_be_validated() {
		// String actualtext="Thank you! Your data has been submitted.";

		lgpage.verifyTextMsg();
	}

	// ----------------------Forget Password Page--------------------

	@Given("user clicks on Forget Password link button")
	public void user_clicks_on_forget_password_link_button() throws InterruptedException {
		hardCodedWait();
		fp.clickForgetPasswordLink();

	}

	@When("user enters the Email {string}")
	public void user_enters_the_email(String email) throws InterruptedException {
		// hardCodedWait();
		fp.enterEmail(email);

	}

	@When("user enters the Mobile Number {string}")
	public void user_enters_the_mobile_number(String mobile) throws InterruptedException {
		fp.EnterMobileNumber(mobile);
		hardCodedWait();

	}

	@When("user clicks on Reset Password button")
	public void user_clicks_on_reset_password_button() throws InterruptedException {
		fp.clickResetPassword();
		hardCodedWait();
	}

	@Then("the text after login should be validated assuccess response")
	public void the_text_after_login_should_be_validated_assuccess_response() {

		String actual = "Forget Password";

		String exp = driver.getTitle();
		Assert.assertEquals(actual, exp);
	}

	
	
	// -------------------Contact Us Page---------------------------------------------
	
	@Given("user clicks on Contact Us link")
	public void user_clicks_on_contact_us_link() {
	    cs.clickContactUsLink();
	}

//	@Given("user enters the below details")
//	public void user_enters_the_below_details(io.cucumber.datatable.DataTable dataTable) {
//	    List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
//
//	    cs.enterYN(data.get(0).get("YourName"));
//	    cs.enterYE(data.get(0).get("YourEmail"));
//	    cs.enterPN(data.get(0).get("PhoneNumber"));
//	    cs.enterAddress(data.get(0).get("Address"));
//	    cs.enterCountry(data.get(0).get("country"));
//	    cs.enterZC(data.get(0).get("ZipCode"));
//	    
//	    cs.ClickSubmit();
//	}
	
	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable dataTable) {
	    Map<String, String> data = dataTable.asMaps().get(0);
	    
	    cs.fillContactForm(
	        data.get("YourName"),
	        data.get("YourEmail"),
	        data.get("PhoneNumber"),
	        data.get("Address"),
	        data.get("country"),
	        data.get("ZipCode")
	    );
	    
	    cs.ClickSubmit();
	    log.info("User entered Contact Us form details and clicked Submit");
	}

	@Then("verify the text post submit button")
	public void verify_the_text_post_submit_button() {
	   // cs.VerifyText();
		
		String Actual="Thank you! Your data has been submitted.";
		String expected=cs.VerifyText();
		
		Assert.assertEquals(expected, Actual.trim());
	}


	
	
	
	
	//------------------------------Tear Down-------------------------------------------
	@After

	public void tearDown(Scenario scenario) {
		System.out.println("After method is executed");

		// Takes screenshot if the scenario fails
		if (scenario.isFailed()) {

			// Define a path and filename for the screenshot
			String screenshotPath = "E:\\GroTech\\Banking_realTimeProject_Bikash_20_04_2025\\Screenshot\\"
					+ scenario.getName().replaceAll(" ", "_") + ".png";

			// Take screenshot
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			File dest = new File(screenshotPath);

			try {
				FileUtils.copyFile(source, dest);
				System.out.println("Screenshot saved at: " + screenshotPath);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// Quit the driver

		if (driver != null) {
			driver.quit();
		}
	}

}
