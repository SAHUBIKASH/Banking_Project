package Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Constants.ConstantsData;
import dev.failsafe.Call;

public class FetchDataFromExcel {
	
	
	public static String getURL() throws IOException
	{
		FileInputStream fis=new FileInputStream(ConstantsData.ExcelPath);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheetAt(0);
		XSSFCell cell= sheet.getRow(1).getCell(0);
		String urlValue=cell.toString();
	
		return urlValue;
		
	}

}
